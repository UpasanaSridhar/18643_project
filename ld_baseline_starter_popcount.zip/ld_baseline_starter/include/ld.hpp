#pragma once
#include <cstdint>
#include <vector>
#include <cstddef>

// SNP-major packed haplotypes: locus i, haplotype k -> bit (k % 64)
struct Haplotypes {
    std::size_t loci, samples;
    std::vector<uint64_t> words;
    std::size_t stride() const { return (samples + 63) / 64; }
    bool bit(std::size_t i, std::size_t k) const {
        return (words[i * stride() + k / 64] >> (k % 64)) & 1ULL;
    }
    void set(std::size_t i, std::size_t k, bool v) {
        const uint64_t mask = 1ULL << (k % 64);
        uint64_t &word = words[i * stride() + k / 64];
        if (v) word |= mask; else word &= ~mask;
    }
};

Haplotypes make_input(std::size_t loci, std::size_t samples, uint32_t seed);
std::vector<uint32_t> packed_counts(const Haplotypes &h);
double r_squared(uint32_t both, uint32_t a, uint32_t b, std::size_t samples);
