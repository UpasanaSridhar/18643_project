#include "ld.hpp"
#include <cmath>
#include <random>
#include <stdexcept>

Haplotypes make_input(std::size_t loci, std::size_t samples, uint32_t seed) {
    if (!loci || !samples) throw std::invalid_argument("loci and samples must be positive");
    Haplotypes h{loci, samples, std::vector<uint64_t>(loci * ((samples + 63) / 64), 0)};
    std::mt19937 rng(seed);
    std::bernoulli_distribution bernoulli(0.35);
    for (std::size_t i = 0; i < loci; ++i)
        for (std::size_t k = 0; k < samples; ++k)
            h.set(i, k, bernoulli(rng));
    // Explicit edge cases for correctness; no missing calls.
    if (loci >= 1) for (std::size_t k = 0; k < samples; ++k) h.set(0, k, false);
    if (loci >= 2) for (std::size_t k = 0; k < samples; ++k) h.set(1, k, true);
    if (loci >= 4) for (std::size_t k = 0; k < samples; ++k) h.set(3, k, h.bit(2, k));
    return h;
}

std::vector<uint32_t> packed_counts(const Haplotypes &h) {
    std::vector<uint32_t> result(h.loci * h.loci, 0);
    for (std::size_t i = 0; i < h.loci; ++i)
        for (std::size_t j = i; j < h.loci; ++j) {
            uint32_t count = 0;
            for (std::size_t w = 0; w < h.stride(); ++w)
                count += static_cast<uint32_t>(__builtin_popcountll(
                    h.words[i * h.stride() + w] & h.words[j * h.stride() + w]));
            result[i * h.loci + j] = result[j * h.loci + i] = count;
        }
    return result;
}

double r_squared(uint32_t both, uint32_t a, uint32_t b, std::size_t n) {
    const double denom = double(a) * (n - a) * double(b) * (n - b);
    if (denom == 0) return std::nan(""); // monomorphic: undefined
    const double numerator = double(n) * both - double(a) * b;
    return numerator * numerator / denom;
}
