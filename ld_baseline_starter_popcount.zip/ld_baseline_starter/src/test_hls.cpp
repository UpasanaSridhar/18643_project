#include "ld.hpp"
#include "../hls/ld_config.hpp"
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <vector>
extern "C" void ld_top(const uint64_t *, const uint64_t *, uint32_t *, int, int, int);

int main(int argc, char **argv) {
    const int loci = argc > 1 ? std::atoi(argv[1]) : 10;
    const int samples = argc > 2 ? std::atoi(argv[2]) : 10;
    const unsigned seed = argc > 3 ? static_cast<unsigned>(std::strtoul(argv[3], nullptr, 10)) : 17;
    if (loci < 1 || samples < 1 || samples > ld_cfg::MAX_K) {
        std::cerr << "Usage: test_hls loci samples<=LD_MAX_K seed\n";
        return 2;
    }
    const auto h = make_input(loci, samples, seed);
    const auto reference = packed_counts(h);
    std::vector<uint32_t> result(loci * loci, 0);
    std::vector<uint64_t> a(ld_cfg::MR * ld_cfg::WORDS, 0);
    std::vector<uint64_t> b(ld_cfg::NR * ld_cfg::WORDS, 0);
    std::vector<uint32_t> c(ld_cfg::MR * ld_cfg::NR, 0);
    for (int i0 = 0; i0 < loci; i0 += ld_cfg::MR) {
        const int m = std::min(ld_cfg::MR, loci - i0);
        for (int j0 = 0; j0 < loci; j0 += ld_cfg::NR) {
            const int n = std::min(ld_cfg::NR, loci - j0);
            std::fill(a.begin(), a.end(), 0);
            std::fill(b.begin(), b.end(), 0);
            for (int i = 0; i < m; ++i)
                for (std::size_t w = 0; w < h.stride(); ++w)
                    a[i * ld_cfg::WORDS + w] = h.words[(i0+i)*h.stride()+w];
            for (int j = 0; j < n; ++j)
                for (std::size_t w = 0; w < h.stride(); ++w)
                    b[j * ld_cfg::WORDS + w] = h.words[(j0+j)*h.stride()+w];
            ld_top(a.data(), b.data(), c.data(), m, n, samples);
            for (int i = 0; i < m; ++i)
                for (int j = 0; j < n; ++j)
                    result[(i0+i)*loci+(j0+j)] = c[i*ld_cfg::NR+j];
            for (int i = 0; i < ld_cfg::MR; ++i)
                for (int j = 0; j < ld_cfg::NR; ++j)
                    if ((i >= m || j >= n) && c[i*ld_cfg::NR+j] != 0) {
                        std::cerr << "FAIL: padding not zero\n"; return 1;
                    }
        }
    }
    int failures = 0;
    for (int i = 0; i < loci; ++i)
        for (int j = 0; j < loci; ++j) {
            const int at = i*loci+j;
            if (result[at] != reference[at]) {
                std::cerr << "MISMATCH (" << i << "," << j << ") ref="
                          << reference[at]
                          << " hls=" << result[at] << "\n";
                ++failures;
            }
            const double r0 = r_squared(reference[at], reference[i*loci+i], reference[j*loci+j], samples);
            const double r1 = r_squared(result[at], result[i*loci+i], result[j*loci+j], samples);
            if (!((std::isnan(r0) && std::isnan(r1)) || std::abs(r0-r1) < 1e-12)) ++failures;
        }
    std::cout << (failures ? "FAIL" : "PASS")
              << " mode=popcount"
              << " MR=" << ld_cfg::MR << " NR=" << ld_cfg::NR
              << " MAX_K=" << ld_cfg::MAX_K << " POP_WIDTH=" << ld_cfg::POP_WIDTH
              << " loci=" << loci << " haplotypes=" << samples
              << " tiles=" << ((loci+ld_cfg::MR-1)/ld_cfg::MR)*((loci+ld_cfg::NR-1)/ld_cfg::NR)
              << " mismatches=" << failures << "\n";
    if (loci <= 10) {
        std::cout << "Intersection counts:\n";
        for (int i=0;i<loci;++i) {
            for (int j=0;j<loci;++j) std::cout << std::setw(4) << result[i*loci+j];
            std::cout << '\n';
        }
    }
    return failures ? 1 : 0;
}
