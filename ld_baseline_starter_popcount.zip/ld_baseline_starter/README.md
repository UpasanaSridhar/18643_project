# Linkage disequilibrium baseline starter

Three pieces only: **quickLD** as the external CPU/GPU baseline, a **naive packed-popcount C++ reference**, and a **configurable popcount Vitis HLS microkernel** for Ultra96-V2. The bit-serial implementation is deliberately postponed.

## Contents

- `scripts/setup_quickld.sh`: clone/build upstream quickLD BLIS baseline (requires network and toolchain). No quickLD source is included.
- `include/ld.hpp`, `src/ld.cpp`: locus-major packed `uint64_t` haplotypes, naive `AND + popcount` counts, and `r²`.
- `hls/ld_config.hpp`: compile-time microkernel parameters.
- `hls/ld_microkernel.hpp`, `hls/ld_top.cpp`: popcount reduction over one `MR × NR` output tile, HLS AXI top.
- `src/test_hls.cpp`: deterministic configurable native C++ correctness test, including edge tiles and partial 64-bit words.

### Native test (x86 or Arm)

```sh
make test
./test_hls 10 10 17   # loci, haplotypes, seed
./test_hls 10 65 17
make sweep          # MR×NR = 2×2, 4×4, 3×5; popcount width = 8,16,64
```

Change the compiled microkernel dimensions:

```sh
make test_hls LD_PARAMS='-DLD_MR=2 -DLD_NR=5 -DLD_MAX_K=128 -DLD_POP_WIDTH=16'
./test_hls 10 65 17
```

The native test compares the HLS microkernel's exact intersection counts against a naive `__builtin_popcountll(A & B)` reference for every pair. It checks `r²` as a derived value. Monomorphic loci have undefined `r²` (NaN), but defined intersection counts.

### Microkernel parameters

| Macro | Default | Meaning |
|---|---:|---|
| `LD_MR` | 4 | Number of loci in output tile rows |
| `LD_NR` | 4 | Number of loci in output tile columns |
| `LD_MAX_K` | 128 | Maximum haplotypes per kernel call; fixes panel stride |
| `LD_POP_WIDTH` | 64 | Bits counted each reduction step; must divide 64 |

Input `A` has shape `MR × ceil(MAX_K/64)`, and `B` has `NR × ceil(MAX_K/64)` 64-bit words, with locus-major rows. Output `C` has shape `MR × NR` with NR stride. Runtime `m`, `n`, `samples` set active dimensions. Host code pads unused panel entries with zero. The HLS kernel calculates integer intersection counts only, not `r²`. It currently computes rectangular tiles; the host controls whether to use SYRK-style triangular scheduling.

### Vitis HLS (Ultra96-V2)

```sh
export LD_PART=xczu3eg-sbva484-1-e
export LD_MR=4 LD_NR=4 LD_MAX_K=128 LD_POP_WIDTH=64
vitis_hls -f hls/run_hls.tcl
```

Set `LD_PART` for the actual device/toolchain. This is **not synthesized or benchmarked yet**. A `PIPELINE II=1` pragma is a request, not a measured II. Popcount is expressed as unrolled bit summation, and **DSP mapping is not guaranteed**. Use utilization and timing reports to evaluate DSP/LUT mapping.

### quickLD (separate baseline)

```sh
bash scripts/setup_quickld.sh
```

On Orin: build CPU BLIS and check the NVIDIA OpenCL runtime before using quickLD's `-gpu` option. On Ultra96-V2 Arm: run the BLIS CPU version. For phased 1000 Genomes VCF, quickLD's documented pipeline uses `qLD-parseVCF`, `qLD-parse-2MDF` with `-ploidy phased_diploid`, then `qLD-compute` with `-mdf -blis` (or `-gpu`). Check the CLI in the installed version.

**Not yet integrated:** quickLD's MDF reader with the C++ and HLS inputs; real data; hardware timing or FPGA results. The included test uses generated packed haplotypes. No bit-serial implementation or SYCL driver is in this revision.
