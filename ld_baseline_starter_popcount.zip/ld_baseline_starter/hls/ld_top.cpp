#include "ld_microkernel.hpp"
// Vitis HLS top-level: one rectangular MR x NR output tile per invocation.
// Host performs tiling and prepares fixed-stride packed input panels.
extern "C" void ld_top(const uint64_t *a, const uint64_t *b,
                       uint32_t *c, int m, int n, int samples) {
    #pragma HLS INTERFACE m_axi port=a offset=slave bundle=gmem0
    #pragma HLS INTERFACE m_axi port=b offset=slave bundle=gmem1
    #pragma HLS INTERFACE m_axi port=c offset=slave bundle=gmem2
    #pragma HLS INTERFACE s_axilite port=m bundle=control
    #pragma HLS INTERFACE s_axilite port=n bundle=control
    #pragma HLS INTERFACE s_axilite port=samples bundle=control
    #pragma HLS INTERFACE s_axilite port=return bundle=control
    if (m < 1 || m > ld_cfg::MR || n < 1 || n > ld_cfg::NR ||
        samples < 1 || samples > ld_cfg::MAX_K) return;
    ld_run_tile(a, b, c, m, n, samples);
}
